class_name PlayScreen
extends Control

signal navigate(target: String)

static var _shape_names := {}

var view: BoardView
var session: LevelSession
var clip: Control
var level_label: Label
var stage_label: Label
var chip_label: Label
var caption_left: Label
var counter_label: Label
var progress_fill: Panel
var hearts: Array[IconView] = []
var sound_icon: IconView
var undo_btn: Button
var hint_btn: Button
var remove_btn: Button
var toast_box: Control

var fail_layer: Control
var done_layer: Control
var pause_layer: Control

var level_no := 1
var wrong_taps := 0
var play_time := 0.0
var total_arrows := 1
var running := false
var paused := false
var removed_now := 0


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(UIKit.vgradient([Color("#E3F6EE"), AppColors.IVORY, AppColors.IVORY], [0.0, 0.22, 1.0]))
	level_no = clampi(GameState.play_level if GameState.play_level > 0 else GameState.current_level, 1, GameState.TOTAL_LEVELS)

	_build_hud()
	session = LevelSession.new()
	add_child(session)
	session.lives_changed.connect(_on_lives)
	session.cleared.connect(_on_cleared)
	session.failed.connect(_on_failed)
	view.wrong_tap.connect(_on_wrong_tap)
	view.arrows_changed.connect(_on_arrows)
	view.booster_removed.connect(_on_booster_removed)
	session.bind(view)
	_refresh_counts()
	_refresh_sound()
	_load()


func _process(delta: float) -> void:
	if running and fail_layer == null and not paused:
		play_time += delta


# ---------------------------------------------------------------- HUD

func _build_hud() -> void:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	margin.add_theme_constant_override("margin_left", 44)
	margin.add_theme_constant_override("margin_right", 44)
	margin.add_theme_constant_override("margin_top", SafeArea.top_margin(60))
	margin.add_theme_constant_override("margin_bottom", SafeArea.bottom_margin(50))
	add_child(margin)
	var col := VBoxContainer.new()
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 0)
	margin.add_child(col)

	col.add_child(_top_bar())
	col.add_child(UIKit.spacer(26))
	col.add_child(_info_row())
	col.add_child(UIKit.spacer(22))
	col.add_child(_progress_bar())
	col.add_child(UIKit.spacer(24))

	var holder := Control.new()
	holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_child(holder)
	var card := Panel.new()
	card.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	card.mouse_filter = Control.MOUSE_FILTER_IGNORE
	card.add_theme_stylebox_override("panel", UIKit.box(Color("#F6EFDD"), 56, 0, 0, 22, Color(0.05, 0.35, 0.33, 0.12), AppColors.CARD_BORDER, 2))
	holder.add_child(card)
	clip = Control.new()
	clip.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT, Control.PRESET_MODE_MINSIZE, 16)
	clip.clip_contents = true
	clip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	holder.add_child(clip)
	view = BoardView.new()
	clip.add_child(view)
	clip.resized.connect(func(): view.set_view_rect(Rect2(Vector2.ZERO, clip.size)))

	col.add_child(UIKit.spacer(18))
	col.add_child(_caption_row())
	col.add_child(UIKit.spacer(16))
	col.add_child(_note_pill())
	col.add_child(UIKit.spacer(24))
	col.add_child(_bottom_row())

	toast_box = Control.new()
	toast_box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_box.z_index = 50
	add_child(toast_box)
	if GameState.DEV_MODE:
		_add_fps()


func _top_bar() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 16)

	var back := UIKit.button("", 20, AppColors.TEAL, UIKit.box(AppColors.WHITE, 52, 0, 0, 14, Color(0.05, 0.35, 0.33, 0.12), AppColors.CARD_BORDER, 2))
	back.custom_minimum_size = Vector2(104, 104)
	var bi := IconView.make(IconView.Kind.ARROW_LEFT, AppColors.TEAL_DARK, 54, 0.09, 0.26)
	bi.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	back.add_child(bi)
	back.pressed.connect(func(): navigate.emit("home"))
	h.add_child(back)

	var mid := VBoxContainer.new()
	mid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mid.alignment = BoxContainer.ALIGNMENT_CENTER
	mid.add_theme_constant_override("separation", 0)
	mid.add_child(UIKit.label("ARROW ESCAPE", 20, AppColors.TEAL_MEDIUM, "bold", 4, HORIZONTAL_ALIGNMENT_CENTER))
	stage_label = UIKit.label("", 42, AppColors.HEADING, "extrabold", 0, HORIZONTAL_ALIGNMENT_CENTER)
	mid.add_child(stage_label)
	h.add_child(mid)

	var gear := UIKit.button("", 20, AppColors.HEADING, UIKit.box(Color(0, 0, 0, 0), 40))
	gear.custom_minimum_size = Vector2(90, 90)
	var gi := IconView.make(IconView.Kind.SLIDERS, AppColors.HEADING, 50, 0.07, 0.15)
	gi.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gear.add_child(gi)
	gear.pressed.connect(func(): _toast("Settings coming soon"))
	h.add_child(gear)

	var pause := UIKit.button("", 20, Color.WHITE, UIKit.box(AppColors.TEAL, 34, 0, 0, 16, Color(AppColors.TEAL, 0.3)))
	pause.custom_minimum_size = Vector2(104, 104)
	var pi := IconView.make(IconView.Kind.PAUSE, Color.WHITE, 56, 0.09, 0.2)
	pi.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause.add_child(pi)
	pause.pressed.connect(_open_pause)
	h.add_child(pause)
	return h


func _info_row() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 6)
	var chip := UIKit.panel(UIKit.box(AppColors.CARD, 18, 16, 6))
	chip_label = UIKit.label("", 17, AppColors.TEXT_SECONDARY, "bold", 2)
	chip.add_child(chip_label)
	left.add_child(chip)
	level_label = UIKit.label("", 64, AppColors.HEADING, "extrabold")
	left.add_child(level_label)
	h.add_child(left)

	var hp := UIKit.panel(UIKit.box(AppColors.WHITE, 50, 24, 14, 14, Color(0.05, 0.35, 0.33, 0.10), AppColors.CARD_BORDER, 2))
	hp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var hh := HBoxContainer.new()
	hh.add_theme_constant_override("separation", 8)
	hp.add_child(hh)
	for i in 3:
		var ic := IconView.make(IconView.Kind.HEART, AppColors.HEART, 44)
		hearts.append(ic)
		hh.add_child(ic)
	h.add_child(hp)

	var cp := UIKit.panel(UIKit.box(AppColors.WHITE, 50, 22, 14, 14, Color(0.05, 0.35, 0.33, 0.10), AppColors.CARD_BORDER, 2))
	cp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 10)
	cp.add_child(ch)
	var ci := IconView.make(IconView.Kind.CHECK, AppColors.TEAL, 34, 0.12)
	ci.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ch.add_child(ci)
	counter_label = UIKit.label("0 / 0", 30, AppColors.HEADING, "bold")
	ch.add_child(counter_label)
	h.add_child(cp)

	var sb := UIKit.button("", 20, AppColors.TEAL, UIKit.box(AppColors.WHITE, 46, 0, 0, 14, Color(0.05, 0.35, 0.33, 0.10), AppColors.CARD_BORDER, 2))
	sb.custom_minimum_size = Vector2(92, 92)
	sb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sound_icon = IconView.make(IconView.Kind.SPEAKER, AppColors.TEAL_DARK, 50, 0.07, 0.12)
	sound_icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	sb.add_child(sound_icon)
	sb.pressed.connect(_on_sound_toggle)
	h.add_child(sb)
	return h


func _progress_bar() -> Control:
	var track := Panel.new()
	track.custom_minimum_size = Vector2(0, 14)
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	track.add_theme_stylebox_override("panel", UIKit.box(AppColors.CARD, 7))
	progress_fill = Panel.new()
	progress_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	progress_fill.add_theme_stylebox_override("panel", UIKit.box(AppColors.TEAL, 7))
	progress_fill.anchor_left = 0.0
	progress_fill.anchor_top = 0.0
	progress_fill.anchor_bottom = 1.0
	progress_fill.anchor_right = 0.02
	progress_fill.offset_left = 0
	progress_fill.offset_right = 0
	progress_fill.offset_top = 0
	progress_fill.offset_bottom = 0
	track.add_child(progress_fill)
	return track


func _caption_row() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	var dot := IconView.make(IconView.Kind.DOT, AppColors.TEAL_MEDIUM, 14)
	dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(dot)
	caption_left = UIKit.label("", 18, AppColors.TEXT_SECONDARY, "bold", 2)
	caption_left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	caption_left.clip_text = true
	h.add_child(caption_left)
	h.add_child(UIKit.label("TAP CYAN ARROW TO FREE", 18, AppColors.TEAL, "bold", 2))
	return h


func _note_pill() -> Control:
	var p := UIKit.panel(UIKit.box(Color(AppColors.CARD, 0.8), 30, 26, 12))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	p.add_child(h)
	var dot := IconView.make(IconView.Kind.DOT, AppColors.TEAL_MEDIUM, 12)
	dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(dot)
	h.add_child(UIKit.label("Arrows never cross · Tap a clear exterior arrow to escape", 22, AppColors.TEXT_SECONDARY, "medium"))
	return UIKit.centered(p)


func _bottom_row() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 16)

	undo_btn = _action_button("UNDO", IconView.Kind.UNDO, AppColors.TEAL_DARK, UIKit.box(AppColors.CARD, 60), AppColors.WHITE, AppColors.TEAL_DARK)
	undo_btn.pressed.connect(_on_undo)
	h.add_child(undo_btn)

	remove_btn = _action_button("REMOVE", IconView.Kind.ARROW_UP, AppColors.HEART, _remove_style(false), Color.WHITE, AppColors.HEART)
	remove_btn.pressed.connect(_on_remove)
	h.add_child(remove_btn)

	hint_btn = _action_button("HINT", IconView.Kind.BULB, Color.WHITE, UIKit.box(AppColors.TEAL, 60, 0, 0, 22, Color(AppColors.TEAL, 0.35)), Color(1, 1, 1, 0.22), Color.WHITE)
	hint_btn.pressed.connect(_on_hint)
	h.add_child(hint_btn)
	return h


func _action_button(text: String, kind: IconView.Kind, fg: Color, style: StyleBoxFlat, badge_bg: Color, badge_fg: Color) -> Button:
	var b := UIKit.button("", 34, fg, style)
	b.custom_minimum_size = Vector2(0, 120)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 10)
	c.add_child(hb)
	var ic := IconView.make(kind, fg, 40, 0.09)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(ic)
	var l := UIKit.label(text, 27, fg, "extrabold", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_child(l)
	var badge := UIKit.panel(UIKit.box(badge_bg, 22, 14, 2))
	badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var cl := UIKit.label("0", 26, badge_fg, "bold", 0, HORIZONTAL_ALIGNMENT_CENTER)
	cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	badge.add_child(cl)
	hb.add_child(badge)
	b.add_child(c)
	b.set_meta("count", cl)
	return b


# ---------------------------------------------------------------- HUD ka kaam

func _on_lives(n: int) -> void:
	for i in hearts.size():
		hearts[i].color = AppColors.HEART if i < n else AppColors.BORDER_DIM
		hearts[i].queue_redraw()


func _on_wrong_tap(_a = null, _b = null) -> void:
	wrong_taps += 1
	AudioManager.play("wrong")
	AudioManager.haptic(60)


func _on_arrows(removed: int, total: int) -> void:
	removed_now = removed
	_sync_remove()
	counter_label.text = "%d / %d" % [removed, total]
	var r := float(removed) / maxf(1.0, float(total))
	var tw := create_tween()
	tw.tween_property(progress_fill, "anchor_right", maxf(r, 0.02), 0.25)


func _refresh_counts() -> void:
	(undo_btn.get_meta("count") as Label).text = str(GameState.undos)
	(hint_btn.get_meta("count") as Label).text = str(GameState.hints)
	undo_btn.modulate.a = 1.0 if GameState.undos > 0 else 0.5
	hint_btn.modulate.a = 1.0 if GameState.hints > 0 else 0.5
	(remove_btn.get_meta("count") as Label).text = str(GameState.removers)
	remove_btn.modulate.a = 1.0 if GameState.removers > 0 else 0.5


func _refresh_sound() -> void:
	sound_icon.kind = IconView.Kind.SPEAKER if GameState.sound_on else IconView.Kind.SPEAKER_OFF
	sound_icon.queue_redraw()


func _on_sound_toggle() -> void:
	GameState.sound_on = not GameState.sound_on
	SaveManager.save_data()
	_refresh_sound()


func _busy() -> bool:
	return paused or not running or done_layer != null or fail_layer != null


func _on_hint() -> void:
	if _busy():
		return
	if GameState.hints <= 0:
		_toast("No hints left")
		return
	if view.show_hint():
		AudioManager.play("hint")
		GameState.hints -= 1
		SaveManager.save_data()
		_refresh_counts()


# ---------- Remove Arrow booster ----------

func _remove_style(active: bool) -> StyleBoxFlat:
	var bg := Color("#FDE8EC")
	if active:
		return UIKit.box(bg, 60, 0, 0, 0, Color(0, 0, 0, 0), AppColors.HEART, 6)
	return UIKit.box(bg, 60)


func _sync_remove() -> void:
	if remove_btn == null:
		return
	var st := _remove_style(view.remove_mode)
	for s in ["normal", "hover", "pressed", "disabled"]:
		remove_btn.add_theme_stylebox_override(s, st)


func _on_remove() -> void:
	if _busy():
		return
	if view.remove_mode:
		view.remove_mode = false     # dobara dabane par band
		_sync_remove()
		return
	if GameState.removers <= 0:
		_toast("No Remove Arrow left. Get more in the Shop")
		return
	view.remove_mode = true
	_sync_remove()
	_toast("Tap any arrow to remove it")


func _on_booster_removed() -> void:
	GameState.removers = maxi(0, GameState.removers - 1)
	SaveManager.save_data()
	_refresh_counts()
	_sync_remove()


func _on_undo() -> void:
	if _busy():
		return
	if GameState.undos <= 0:
		_toast("No undos left")
		return
	if view.undo():
		GameState.undos -= 1
		SaveManager.save_data()
		_refresh_counts()
	else:
		_toast("Nothing to undo")


func _toast(text: String) -> void:
	var p := UIKit.panel(UIKit.box(AppColors.TEAL_DARK, 40, 36, 18, 20, Color(0, 0, 0, 0.2)))
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(UIKit.label(text, 30, Color.WHITE, "semibold"))
	toast_box.add_child(p)
	await get_tree().process_frame
	var vp := get_viewport_rect().size
	p.position = Vector2((vp.x - p.size.x) / 2.0, vp.y * 0.82)
	var tw := create_tween()
	tw.tween_interval(1.1)
	tw.tween_property(p, "modulate:a", 0.0, 0.4)
	tw.tween_callback(p.queue_free)


# ---------------------------------------------------------------- Level load

func _shape_name(n: int) -> String:
	var ch := floori((n - 1) / 100.0) + 1
	if not _shape_names.has(ch):
		var list: Array = []
		var path := "res://levels/data/chapter_%02d.json" % ch
		if FileAccess.file_exists(path):
			var f := FileAccess.open(path, FileAccess.READ)
			if f != null:
				var d = JSON.parse_string(f.get_as_text())
				if typeof(d) == TYPE_DICTIONARY and typeof(d.get("levels")) == TYPE_ARRAY:
					for l in d["levels"]:
						list.append(str(l.get("shape", "")) if typeof(l) == TYPE_DICTIONARY else "")
		_shape_names[ch] = list
	var arr: Array = _shape_names[ch]
	var i := (n - 1) % 100
	if i < arr.size() and str(arr[i]) != "":
		return str(arr[i])
	return "Stage %d" % n


func _load() -> void:
	var r := LevelLoader.load_level(level_no)
	if r.is_empty():
		# Level file nahi mili / kharab hai: atakne ki jagah Level Select par wapas
		_toast("Could not load this level")
		await get_tree().create_timer(1.3).timeout
		if is_inside_tree():
			navigate.emit("levels")
		return
	var shape := _shape_name(level_no)
	total_arrows = maxi(1, r["board"].arrows.size())
	level_label.text = "Level %d" % level_no
	stage_label.text = shape
	chip_label.text = "%s · %d ARROWS" % [GameState.tier_label(level_no).to_upper(), total_arrows]
	caption_left.text = "%s · ZERO COLLISION LANES" % shape.to_upper()
	wrong_taps = 0
	play_time = 0.0
	view.input_locked = false
	view.load_level(r["rows"], r["board"])
	session.reset()
	running = true


# ---------------------------------------------------------------- PAUSE

func _open_pause() -> void:
	if _busy():
		return
	paused = true
	view.input_locked = true
	view.process_mode = Node.PROCESS_MODE_DISABLED
	_build_pause()


func _close_pause() -> void:
	if pause_layer != null:
		pause_layer.queue_free()
		pause_layer = null
	paused = false
	view.process_mode = Node.PROCESS_MODE_INHERIT
	view.input_locked = false


func _build_pause() -> void:
	pause_layer = Control.new()
	pause_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.z_index = 40
	add_child(pause_layer)

	var dim := ColorRect.new()
	dim.color = Color(AppColors.TEAL_DARK, 0.55)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_layer.add_child(center)

	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", -70)
	center.add_child(stack)

	var circle := UIKit.panel(UIKit.box(AppColors.TEAL, 70, 0, 0, 24, Color(AppColors.TEAL, 0.4)), Vector2(140, 140))
	circle.z_index = 1
	var pi := IconView.make(IconView.Kind.PAUSE, Color.WHITE, 70, 0.1)
	pi.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	pi.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	circle.add_child(pi)
	stack.add_child(UIKit.centered(circle))

	var card := UIKit.panel(UIKit.box(AppColors.IVORY, 70, 56, 50, 30), Vector2(880, 0))
	stack.add_child(card)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 22)
	card.add_child(v)

	v.add_child(UIKit.spacer(60))
	v.add_child(UIKit.label("GAME PAUSED", 56, AppColors.HEADING, "extrabold", 2, HORIZONTAL_ALIGNMENT_CENTER))
	var chip := UIKit.panel(UIKit.box(AppColors.CARD, 24, 22, 8))
	var ch := HBoxContainer.new()
	ch.add_theme_constant_override("separation", 10)
	chip.add_child(ch)
	var cd := IconView.make(IconView.Kind.DOT, AppColors.TEAL_MEDIUM, 12)
	cd.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	ch.add_child(cd)
	ch.add_child(UIKit.label("Level %d · %s" % [level_no, _shape_name(level_no)], 24, AppColors.TEXT_SECONDARY, "semibold"))
	v.add_child(UIKit.centered(chip))
	v.add_child(UIKit.spacer(8))

	var resume := _icon_button("RESUME", IconView.Kind.PLAY_TRI, Color.WHITE,
		UIKit.box(AppColors.TEAL, 65, 0, 0, 26, Color(AppColors.TEAL, 0.35)), 130, 36, true)
	resume.pressed.connect(_close_pause)
	v.add_child(resume)
	var restart := _icon_button("RESTART LEVEL", IconView.Kind.REPLAY, AppColors.TEAL_DARK,
		UIKit.box(AppColors.CARD, 60), 118, 30, true)
	restart.pressed.connect(func():
		_close_pause()
		_load())
	v.add_child(restart)
	var home := _icon_button("HOME", IconView.Kind.HOME, AppColors.TEAL_DARK,
		UIKit.box(AppColors.CARD, 60), 118, 30, true)
	home.pressed.connect(func(): navigate.emit("home"))
	v.add_child(home)

	var tp := UIKit.panel(UIKit.box(Color(AppColors.CARD, 0.6), 50, 22, 18))
	var th := HBoxContainer.new()
	th.add_theme_constant_override("separation", 20)
	tp.add_child(th)
	th.add_child(_toggle_pill(IconView.Kind.SPEAKER, IconView.Kind.SPEAKER_OFF, "SOUND",
		func() -> bool: return GameState.sound_on,
		func(on: bool): GameState.sound_on = on))
	th.add_child(_toggle_pill(IconView.Kind.MUSIC, IconView.Kind.MUSIC, "MUSIC",
		func() -> bool: return GameState.music_on,
		func(on: bool): GameState.music_on = on))
	v.add_child(UIKit.spacer(4))
	v.add_child(tp)


func _toggle_pill(kind_on: IconView.Kind, kind_off: IconView.Kind, text: String, is_on: Callable, set_on: Callable) -> Button:
	var b := UIKit.button("", 24, AppColors.TEAL_DARK, UIKit.box(AppColors.MINT_SOFT, 40))
	b.custom_minimum_size = Vector2(0, 96)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 12)
	c.add_child(hb)
	var ic := IconView.make(kind_on, AppColors.TEAL_DARK, 40, 0.09)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(ic)
	var l := UIKit.label(text, 26, AppColors.TEAL_DARK, "bold", 3)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_child(l)
	b.add_child(c)
	var apply := func() -> void:
		var on: bool = is_on.call()
		var st := UIKit.box(AppColors.MINT_SOFT if on else AppColors.CARD, 40)
		for s in ["normal", "hover", "pressed", "disabled"]:
			b.add_theme_stylebox_override(s, st)
		var fg: Color = AppColors.TEAL_DARK if on else AppColors.TEXT_MUTED
		ic.color = fg
		ic.kind = kind_on if on else kind_off
		ic.queue_redraw()
		l.add_theme_color_override("font_color", fg)
	apply.call()
	b.pressed.connect(func():
		set_on.call(not (is_on.call() as bool))
		SaveManager.save_data()
		apply.call()
		_refresh_sound())
	return b


# ---------------------------------------------------------------- LEVEL COMPLETE

func _on_cleared() -> void:
	running = false
	AudioManager.play("win")
	AudioManager.haptic(90)
	view.input_locked = true
	if level_no == GameState.current_level:
		GameState.current_level = mini(level_no + 1, GameState.TOTAL_LEVELS)
	await get_tree().create_timer(0.6).timeout
	if is_inside_tree():
		_show_complete()


func _stars_for(w: int) -> int:
	if w == 0:
		return 3
	if w == 1:
		return 2
	return 1


func _show_complete() -> void:
	if done_layer != null:
		return
	var stars := _stars_for(wrong_taps)
	var earned := 30 + 40 * stars
	GameState.coins += earned
	SaveManager.record_clear(level_no, stars)
	var acc := 100.0 * total_arrows / float(total_arrows + wrong_taps)
	var secs := int(play_time)
	var time_text := "%02d:%02d" % [floori(secs / 60.0), secs % 60]

	done_layer = Control.new()
	done_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(done_layer)
	done_layer.add_child(UIKit.vgradient([Color("#DDF5EC"), AppColors.IVORY, AppColors.IVORY], [0.0, 0.4, 1.0]))

	var col := VBoxContainer.new()
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	done_layer.add_child(col)

	col.add_child(_chip("LEVEL %02d COMPLETED" % level_no, IconView.Kind.CHECK))
	col.add_child(UIKit.spacer(34))
	col.add_child(UIKit.label("LEVEL COMPLETE!", 84, AppColors.HEADING, "extrabold", 2, HORIZONTAL_ALIGNMENT_CENTER))
	col.add_child(UIKit.spacer(8))
	var sub := HBoxContainer.new()
	sub.alignment = BoxContainer.ALIGNMENT_CENTER
	sub.add_theme_constant_override("separation", 14)
	sub.add_child(UIKit.label("Amazing! All Arrows Escaped!", 34, AppColors.TEXT_SECONDARY, "medium"))
	var sp := IconView.make(IconView.Kind.SPARK, AppColors.MINT, 34)
	sp.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sub.add_child(sp)
	col.add_child(sub)
	col.add_child(UIKit.spacer(56))
	col.add_child(_stars_row(stars))
	col.add_child(UIKit.spacer(30))
	var perf := "PERFECT PERFORMANCE" if stars == 3 else ("GREAT JOB" if stars == 2 else "KEEP GOING")
	col.add_child(_chip(perf, IconView.Kind.STAR))
	col.add_child(UIKit.spacer(50))
	col.add_child(_stats_card(earned, wrong_taps, time_text, acc))
	col.add_child(UIKit.spacer(50))

	var next := _icon_button("NEXT LEVEL", IconView.Kind.ARROW_RIGHT, Color.WHITE,
		UIKit.box(AppColors.TEAL, 75, 0, 0, 30, Color(AppColors.TEAL, 0.35)), 150, 44, false)
	next.pressed.connect(_on_next)
	col.add_child(next)
	col.add_child(UIKit.spacer(26))

	var two := HBoxContainer.new()
	two.add_theme_constant_override("separation", 24)
	var white := UIKit.box(AppColors.WHITE, 60, 0, 0, 16, Color(0.05, 0.35, 0.33, 0.10), AppColors.CARD_BORDER, 2)
	var rep := _icon_button("Replay", IconView.Kind.REPLAY, AppColors.TEAL_DARK, white, 120, 34, true)
	rep.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rep.pressed.connect(_on_replay)
	two.add_child(rep)
	var lev := _icon_button("Levels", IconView.Kind.GRID, AppColors.TEAL_DARK, white, 120, 34, true)
	lev.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lev.pressed.connect(func(): navigate.emit("levels"))
	two.add_child(lev)
	col.add_child(two)

	done_layer.modulate.a = 0.0
	create_tween().tween_property(done_layer, "modulate:a", 1.0, 0.25)
	_fit_center(col, 960.0)


# Content ko naap kar screen ke beech mein rakhta hai; bada ho to chhota kar deta hai
func _fit_center(col: Control, width: float) -> void:
	col.custom_minimum_size = Vector2(width, 0)
	await get_tree().process_frame
	if not is_instance_valid(col):
		return
	var need: Vector2 = col.get_combined_minimum_size()
	col.size = Vector2(maxf(width, need.x), need.y)
	var vp := get_viewport_rect().size
	var s := minf(1.0, minf((vp.y - 100.0) / need.y, (vp.x - 60.0) / col.size.x))
	col.pivot_offset = col.size / 2.0
	col.scale = Vector2(s, s)
	col.position = (vp - col.size) / 2.0


func _chip(text: String, kind: IconView.Kind) -> Control:
	var p := UIKit.panel(UIKit.box(AppColors.CARD, 40, 30, 14))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	p.add_child(h)
	var ic := IconView.make(kind, AppColors.TEAL_MEDIUM if kind == IconView.Kind.CHECK else AppColors.GOLD_STAR, 30, 0.12)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(ic)
	h.add_child(UIKit.label(text, 24, AppColors.TEXT_SECONDARY, "semibold", 4))
	return UIKit.centered(p)


func _stars_row(stars: int) -> Control:
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 34)
	var sizes := [210.0, 300.0, 210.0]
	var rots := [-0.14, 0.0, 0.14]
	var ranks := [2, 1, 3]   # beech wala sabse pehle jalta hai
	for i in 3:
		var got: bool = stars >= ranks[i]
		var sz: float = sizes[i]
		var bg: Color = Color.WHITE if got else AppColors.CARD_LOW
		var tile := UIKit.panel(UIKit.box(bg, 60, 0, 0, 26 if got else 0, Color(AppColors.GOLD_STAR, 0.28)), Vector2(sz, sz))
		tile.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		tile.rotation = rots[i]
		tile.resized.connect(func(): tile.pivot_offset = tile.size / 2.0)
		var col: Color = AppColors.GOLD_STAR if got else AppColors.BORDER_DIM
		var star := IconView.make(IconView.Kind.STAR, col, sz * 0.6, 0.06)
		star.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		star.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		tile.add_child(star)
		row.add_child(tile)
		if got:
			tile.scale = Vector2.ZERO
			var tw := tile.create_tween()
			tw.tween_property(tile, "scale", Vector2.ONE, 0.45).set_delay(0.25 + 0.2 * (ranks[i] - 1)).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	return row


func _stats_card(earned: int, wrong: int, time_text: String, acc: float) -> Control:
	var card := UIKit.panel(UIKit.box(AppColors.WHITE, 60, 36, 36, 26))
	var cv := VBoxContainer.new()
	cv.add_theme_constant_override("separation", 30)
	card.add_child(cv)

	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 10)
	stats.add_child(_stat("COINS EARNED", "+%d" % earned, Color(AppColors.GOLD_STAR, 0.18), IconView.Kind.COIN, AppColors.GOLD_COIN, Color("#D97706")))
	stats.add_child(_stat("WRONG TAPS", "%02d" % wrong, Color(AppColors.HEART, 0.12), IconView.Kind.SHIELD, AppColors.HEART, AppColors.HEADING))
	stats.add_child(_stat("TIME TAKEN", time_text, Color(AppColors.MINT_SOFT, 0.55), IconView.Kind.CLOCK, AppColors.TEAL, AppColors.HEADING))
	cv.add_child(stats)

	var acc_row := HBoxContainer.new()
	acc_row.add_theme_constant_override("separation", 14)
	acc_row.add_child(IconView.make(IconView.Kind.CHECK, AppColors.TEXT_SECONDARY, 34, 0.1))
	acc_row.add_child(UIKit.label("Accuracy Score", 28, AppColors.TEXT_SECONDARY, "medium"))
	var ex := Control.new()
	ex.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ex.mouse_filter = Control.MOUSE_FILTER_IGNORE
	acc_row.add_child(ex)
	var pill := UIKit.panel(UIKit.box(AppColors.MINT_SOFT, 30, 24, 8))
	pill.add_child(UIKit.label("%.1f%%" % acc, 28, AppColors.TEAL, "bold"))
	acc_row.add_child(pill)
	cv.add_child(acc_row)
	return card


func _stat(title: String, value: String, bg: Color, kind: IconView.Kind, icon_color: Color, value_color: Color) -> Control:
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 12)
	var circle := UIKit.panel(UIKit.box(bg, 80), Vector2(160, 160))
	var ic := IconView.make(kind, icon_color, 76, 0.09)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	circle.add_child(ic)
	v.add_child(UIKit.centered(circle))
	v.add_child(UIKit.label(title, 20, AppColors.TEXT_SECONDARY, "bold", 2, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UIKit.label(value, 52, value_color, "extrabold", 0, HORIZONTAL_ALIGNMENT_CENTER))
	return v


func _icon_button(text: String, kind: IconView.Kind, fg: Color, style: StyleBoxFlat, h: float, fs: int, icon_first: bool) -> Button:
	var b := UIKit.button("", fs, fg, style)
	b.custom_minimum_size = Vector2(0, h)
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_theme_constant_override("separation", 16)
	c.add_child(hb)
	var l := UIKit.label(text, fs, fg, "extrabold" if not icon_first else "bold", 3)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var ic := IconView.make(kind, fg, fs * 1.1, 0.1)
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	if icon_first:
		hb.add_child(ic)
		hb.add_child(l)
	else:
		hb.add_child(l)
		hb.add_child(ic)
	b.add_child(c)
	return b


func _close_done() -> void:
	if done_layer != null:
		done_layer.queue_free()
		done_layer = null


func _on_next() -> void:
	_close_done()
	level_no = mini(level_no + 1, GameState.TOTAL_LEVELS)
	_load()


func _on_replay() -> void:
	_close_done()
	_load()


# ---------------------------------------------------------------- LEVEL FAILED

func _on_failed() -> void:
	running = false
	AudioManager.play("fail")
	AudioManager.haptic(120)
	view.input_locked = true
	_show_failed()


func _show_failed() -> void:
	if fail_layer != null:
		return
	var pct := int(round(100.0 * removed_now / maxf(1.0, float(total_arrows))))

	fail_layer = Control.new()
	fail_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fail_layer.z_index = 30
	add_child(fail_layer)

	var dim := ColorRect.new()
	dim.color = Color(AppColors.TEAL_DARK, 0.6)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fail_layer.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fail_layer.add_child(center)

	var card := UIKit.panel(UIKit.box(AppColors.IVORY, 70, 52, 44, 30), Vector2(880, 0))
	center.add_child(card)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 16)
	card.add_child(v)

	v.add_child(_fail_art())
	v.add_child(UIKit.label("LEVEL FAILED", 64, AppColors.HEADING, "extrabold", 2, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UIKit.label("Oops! You're out of lives.", 32, AppColors.TEXT_SECONDARY, "medium", 0, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UIKit.label("Don't give up. Try again!", 24, AppColors.TEXT_MUTED, "regular", 0, HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UIKit.spacer(4))
	v.add_child(_fail_progress(pct))
	v.add_child(UIKit.spacer(4))

	var again := _icon_button("TRY AGAIN", IconView.Kind.REPLAY, Color.WHITE,
		UIKit.box(AppColors.TEAL, 65, 0, 0, 26, Color(AppColors.TEAL, 0.35)), 130, 36, true)
	again.pressed.connect(_on_restart)
	v.add_child(again)

	v.add_child(_watch_ad_button())

	var home := _icon_button("Home", IconView.Kind.HOME, AppColors.TEXT_SECONDARY,
		UIKit.box(Color(AppColors.CARD, 0.5), 50), 100, 28, true)
	home.pressed.connect(func(): navigate.emit("home"))
	v.add_child(home)


# Upar ki chhoti tasveer: gol dial, lal suyi, aas-paas dots
func _fail_art() -> Control:
	var holder := Control.new()
	holder.custom_minimum_size = Vector2(0, 190)
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var dial := IconView.make(IconView.Kind.DIAL, AppColors.TEAL_DARK, 170, 0.05)
	dial.size = Vector2(170, 170)
	dial.position = Vector2(880 - 104 - 170, 0) / 2.0 + Vector2(0, 10)
	holder.add_child(dial)
	var bits := [
		[IconView.Kind.DOT, Vector2(300, 40), AppColors.TEAL_DARK, 14.0],
		[IconView.Kind.DOT, Vector2(560, 150), Color(AppColors.HEART, 0.45), 16.0],
		[IconView.Kind.STAR, Vector2(240, 150), Color(AppColors.HEART, 0.4), 26.0],
		[IconView.Kind.CHEVRON_RIGHT, Vector2(540, 20), AppColors.MINT, 30.0],
	]
	for b in bits:
		var px: float = b[3]
		var ic := IconView.make(b[0], b[2], px, 0.1)
		ic.position = b[1]
		ic.size = Vector2(px, px)
		holder.add_child(ic)
	return holder


func _fail_progress(pct: int) -> Control:
	var box := UIKit.panel(UIKit.box(Color(AppColors.CARD, 0.7), 30, 28, 20))
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	box.add_child(col)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var fl := IconView.make(IconView.Kind.FLAG, AppColors.TEAL_DARK, 32, 0.1)
	fl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(fl)
	var lv_label := UIKit.label("Level %d" % level_no, 26, AppColors.HEADING, "bold")
	lv_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(lv_label)
	row.add_child(UIKit.label("%d%%" % pct, 36, AppColors.TEAL, "extrabold"))
	col.add_child(row)
	var track := Panel.new()
	track.custom_minimum_size = Vector2(0, 14)
	track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	track.add_theme_stylebox_override("panel", UIKit.box(AppColors.BORDER_DIM, 7))
	var fill := Panel.new()
	fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill.add_theme_stylebox_override("panel", UIKit.box(AppColors.TEAL_MEDIUM, 7))
	fill.anchor_right = maxf(float(pct) / 100.0, 0.02)
	fill.anchor_bottom = 1.0
	track.add_child(fill)
	col.add_child(track)
	return box


# Abhi free continue hai; ad baad mein yahin judega
func _watch_ad_button() -> Button:
	var b := UIKit.button("", 20, AppColors.TEAL_DARK, UIKit.box(Color("#C5F6EC"), 50))
	b.custom_minimum_size = Vector2(0, 140)
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_theme_constant_override("separation", 6)
	c.add_child(vb)
	var hb := HBoxContainer.new()
	hb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_theme_constant_override("separation", 12)
	var pl := IconView.make(IconView.Kind.PLAY_TRI, AppColors.TEAL_DARK, 30, 0.09)
	pl.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	hb.add_child(pl)
	var l := UIKit.label("WATCH AD TO CONTINUE", 26, AppColors.TEAL_DARK, "extrabold", 1)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hb.add_child(l)
	var chip := UIKit.panel(UIKit.box(AppColors.MINT, 18, 14, 3))
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var cl := UIKit.label("+3 Lives", 20, AppColors.TEAL_DARK, "bold")
	cl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chip.add_child(cl)
	hb.add_child(chip)
	vb.add_child(hb)
	var sub := UIKit.label("Get another chance!", 22, AppColors.TEXT_SECONDARY, "medium", 0, HORIZONTAL_ALIGNMENT_CENTER)
	sub.mouse_filter = Control.MOUSE_FILTER_IGNORE
	vb.add_child(sub)
	b.add_child(c)
	b.pressed.connect(_on_continue)
	return b


func _close_failed() -> void:
	if fail_layer != null:
		fail_layer.queue_free()
		fail_layer = null


func _on_continue() -> void:
	_close_failed()
	running = true
	view.input_locked = false
	session.continue_with_extra_lives(3)


func _on_restart() -> void:
	_close_failed()
	_load()


# ---------- Testing: FPS dikhao (sirf DEV_MODE me) ----------

func _add_fps() -> void:
	var fps := UIKit.label("", 22, AppColors.TEAL_DARK, "bold")
	fps.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fps.position = Vector2(14, 6)
	fps.z_index = 60
	add_child(fps)
	var tm := Timer.new()
	tm.wait_time = 0.5
	tm.autostart = true
	tm.timeout.connect(func(): fps.text = "FPS %d" % Engine.get_frames_per_second())
	add_child(tm)


# ---------- Phone ka Back button ----------

func on_back() -> void:
	if paused:
		_close_pause()
	elif fail_layer != null or not running:
		navigate.emit("levels")
	else:
		_open_pause()
