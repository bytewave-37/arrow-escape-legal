class_name HomeScreen
extends Control

signal navigate(target: String)

var gift_btn: Button
var daily_open := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(UIKit.vgradient(
		[Color("#D9F4EA"), Color("#F4F7EA"), AppColors.IVORY, AppColors.CARD_LOW],
		[0.0, 0.35, 0.6, 1.0]))

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 56)
	margin.add_theme_constant_override("margin_right", 56)
	margin.add_theme_constant_override("margin_top", SafeArea.top_margin(70))
	margin.add_theme_constant_override("margin_bottom", SafeArea.bottom_margin(56))
	add_child(margin)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 0)
	margin.add_child(col)

	col.add_child(_decor_row())
	col.add_child(UIKit.spacer(46))
	col.add_child(_logo())
	col.add_child(UIKit.spacer(36))
	col.add_child(_pill("A MINIMAL PUZZLE JOURNEY"))
	col.add_child(UIKit.spacer(30))
	col.add_child(_title())
	col.add_child(UIKit.spacer(10))
	col.add_child(UIKit.label("Untangle vectors. Find the clear path.", 34, AppColors.TEXT_MUTED, "regular", 0, HORIZONTAL_ALIGNMENT_CENTER))
	col.add_child(UIKit.spacer(64))
	col.add_child(_level_card())
	col.add_child(UIKit.spacer(56))
	col.add_child(_play_button())
	col.add_child(UIKit.spacer(50))
	col.add_child(_info_row())
	col.add_child(UIKit.expander())
	col.add_child(_nav())

	# Daily reward: gift button + (har session mein ek baar) popup
	if GameState.daily_available():
		_add_gift_button()
		if not GameState.daily_popup_shown:
			GameState.daily_popup_shown = true
			await get_tree().create_timer(0.6).timeout
			if is_inside_tree():
				_open_daily()


func _add_gift_button() -> void:
	gift_btn = UIKit.button("", 20, AppColors.TEAL, UIKit.box(AppColors.WHITE, 55, 0, 0, 18, Color(AppColors.MINT, 0.5)))
	gift_btn.custom_minimum_size = Vector2(110, 110)
	gift_btn.size = Vector2(110, 110)
	gift_btn.position = Vector2(1080 - 56 - 110, SafeArea.top_margin(52))
	var gi := IconView.make(IconView.Kind.GIFT, AppColors.TEAL_DARK, 70, 0.07, 0.2)
	gi.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	gift_btn.add_child(gi)
	var dot := Panel.new()
	dot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dot.add_theme_stylebox_override("panel", UIKit.box(AppColors.HEART, 14, 0, 0, 0, Color(0, 0, 0, 0), Color.WHITE, 3))
	dot.position = Vector2(80, 8)
	dot.size = Vector2(28, 28)
	gift_btn.add_child(dot)
	gift_btn.pressed.connect(_open_daily)
	add_child(gift_btn)


func _open_daily() -> void:
	if daily_open:
		return
	daily_open = true
	var pop := DailyRewardPopup.new()
	pop.closed.connect(func(claimed: bool):
		daily_open = false
		if claimed and gift_btn:
			gift_btn.queue_free()
			gift_btn = null)
	add_child(pop)


func _decor_row() -> Control:
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 90)
	var kinds := [IconView.Kind.ARROW_DOWN, IconView.Kind.ARROW_RIGHT, IconView.Kind.DOT, IconView.Kind.ARROW_LEFT, IconView.Kind.ARROW_DOWN]
	for k in kinds:
		var px := 14.0 if k == IconView.Kind.DOT else 54.0
		var ic := IconView.make(k, AppColors.TEAL_MEDIUM, px, 0.07)
		ic.modulate.a = 0.35
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(ic)
	return h


func _logo() -> Control:
	var p := UIKit.panel(UIKit.box(AppColors.WHITE, 62, 0, 0, 40, Color(AppColors.MINT, 0.35)), Vector2(200, 200))
	var ic := IconView.make(IconView.Kind.LOGO_UP, AppColors.TEAL, 110, 0.11)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_child(ic)
	return UIKit.centered(p)


func _pill(text: String) -> Control:
	var p := UIKit.panel(UIKit.box(Color(AppColors.CARD, 0.75), 40, 30, 14))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	p.add_child(h)
	var dot := IconView.make(IconView.Kind.DOT, AppColors.TEAL_MEDIUM, 14)
	dot.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(dot)
	h.add_child(UIKit.label(text, 24, AppColors.TEXT_SECONDARY, "semibold", 4))
	return UIKit.centered(p)


func _title() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 26)
	h.add_child(UIKit.label("ARROW", 96, AppColors.HEADING, "extrabold", 10))
	h.add_child(UIKit.label("ESCAPE", 96, AppColors.TEAL_MEDIUM, "regular", 10))
	return UIKit.centered(h)


func _level_card() -> Control:
	var n := GameState.current_level
	var card := UIKit.panel(UIKit.box(AppColors.WHITE, 70, 48, 38, 28), Vector2(0, 250))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 20)
	card.add_child(row)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	left.add_theme_constant_override("separation", 4)
	left.add_child(UIKit.label("CURRENT LEVEL", 24, AppColors.TEAL_MEDIUM, "bold", 4))
	left.add_child(UIKit.label("LEVEL %02d" % n, 76, AppColors.HEADING, "bold"))
	left.add_child(UIKit.label("Chapter %d · %s" % [GameState.chapter_of(n), GameState.chapter_name(n)], 28, AppColors.TEXT_MUTED, "regular"))
	row.add_child(left)

	var right := VBoxContainer.new()
	right.alignment = BoxContainer.ALIGNMENT_CENTER
	right.add_theme_constant_override("separation", 14)
	var dots := HBoxContainer.new()
	dots.alignment = BoxContainer.ALIGNMENT_END
	dots.add_theme_constant_override("separation", 8)
	for i in 3:
		var dc: Color = AppColors.TEAL if i == 0 else AppColors.BORDER_DIM
		dots.add_child(IconView.make(IconView.Kind.DOT, dc, 14))
	right.add_child(dots)
	var chips := HBoxContainer.new()
	chips.alignment = BoxContainer.ALIGNMENT_END
	chips.add_theme_constant_override("separation", 16)
	var tier := UIKit.panel(UIKit.box(AppColors.CARD, 30, 24, 12))
	tier.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	tier.add_child(UIKit.label(GameState.tier_label(n), 26, AppColors.TEXT_SECONDARY, "semibold"))
	chips.add_child(tier)
	chips.add_child(_grid_button())
	right.add_child(chips)
	row.add_child(right)
	return card


func _grid_button() -> Control:
	var b := UIKit.button("", 20, AppColors.TEAL, UIKit.box(AppColors.CARD, 36))
	b.custom_minimum_size = Vector2(120, 120)
	var icon := IconView.make(IconView.Kind.GRID, AppColors.TEAL, 60, 0.09, 0.26)
	icon.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	b.add_child(icon)
	b.pressed.connect(func(): navigate.emit("levels"))
	return b


func _play_button() -> Control:
	var style := UIKit.box(AppColors.TEAL, 87, 0, 0, 34, Color(AppColors.TEAL, 0.35))
	var b := UIKit.button("PLAY", 54, Color.WHITE, style, "extrabold", 14)
	b.custom_minimum_size = Vector2(0, 174)
	var chip := Panel.new()
	chip.add_theme_stylebox_override("panel", UIKit.box(Color(1, 1, 1, 0.18), 36))
	chip.anchor_left = 1.0
	chip.anchor_right = 1.0
	chip.anchor_top = 0.5
	chip.anchor_bottom = 0.5
	chip.offset_left = -150
	chip.offset_right = -36
	chip.offset_top = -57
	chip.offset_bottom = 57
	chip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	b.add_child(chip)
	var arrow := IconView.make(IconView.Kind.ARROW_RIGHT, Color.WHITE, 114, 0.09, 0.25)
	arrow.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	chip.add_child(arrow)
	b.pressed.connect(func():
		GameState.play_level = GameState.current_level
		navigate.emit("play"))
	return b


func _info_row() -> Control:
	var h := HBoxContainer.new()
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	h.add_theme_constant_override("separation", 14)
	h.add_child(IconView.make(IconView.Kind.CLOCK, AppColors.TEXT_SECONDARY, 38, 0.08))
	h.add_child(UIKit.label("No Time Limit", 26, AppColors.TEXT_SECONDARY, "medium"))
	var d := IconView.make(IconView.Kind.DOT, AppColors.BORDER_DIM, 10)
	d.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(d)
	h.add_child(IconView.make(IconView.Kind.SPARK, AppColors.TEXT_SECONDARY, 34))
	h.add_child(UIKit.label("Mindful Play", 26, AppColors.TEXT_SECONDARY, "medium"))
	return h


func _nav() -> Control:
	var pill := UIKit.panel(UIKit.box(AppColors.WHITE, 95, 18, 18, 36), Vector2(0, 190))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	pill.add_child(h)
	h.add_child(_nav_item(IconView.Kind.PLAY_CIRCLE, "Home", true, "home"))
	h.add_child(_nav_item(IconView.Kind.SHOP, "Shop", false, "shop"))
	h.add_child(_nav_item(IconView.Kind.SLIDERS, "Settings", false, "settings"))
	return pill


func _nav_item(kind: IconView.Kind, text: String, selected: bool, target: String) -> Control:
	var fg: Color = Color.WHITE if selected else AppColors.TEXT_MUTED
	var bg: Color = AppColors.TEAL if selected else Color(0, 0, 0, 0)
	var b := UIKit.button("", 20, fg, UIKit.box(bg, 78))
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 154)
	var c := CenterContainer.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var h := HBoxContainer.new()
	h.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_theme_constant_override("separation", 14)
	c.add_child(h)
	h.add_child(IconView.make(kind, fg, 48, 0.08))
	var l := UIKit.label(text, 32, fg, "bold" if selected else "medium")
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	h.add_child(l)
	b.add_child(c)
	if not selected:
		b.pressed.connect(func(): navigate.emit(target))
	return b


# Phone ka Back button: Home par dabane se game band
func on_back() -> void:
	if daily_open:
		return
	get_tree().quit()
