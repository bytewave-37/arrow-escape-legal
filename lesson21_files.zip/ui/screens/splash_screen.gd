class_name SplashScreen
extends Control

signal navigate(target: String)


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(UIKit.vgradient([AppColors.IVORY, Color("#F7F0E1")], [0.0, 1.0]))

	var glow := UIKit.glow(AppColors.MINT, 1100)
	glow.position = Vector2(540 - 550, 780 - 550)
	add_child(glow)
	_decor()

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 26)
	center.add_child(col)

	col.add_child(_logo())
	col.add_child(UIKit.spacer(24))
	col.add_child(_title())
	col.add_child(_divider())
	col.add_child(_tagline())

	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.6)
	await get_tree().create_timer(2.4).timeout
	if is_inside_tree():
		# Pehli baar: How to Play; uske baad seedha Home
		navigate.emit("home" if GameState.tutorial_seen else "tutorial")


func _logo() -> Control:
	var p := UIKit.panel(UIKit.box(AppColors.WHITE, 84, 0, 0, 46, Color(AppColors.MINT, 0.4)), Vector2(270, 270))
	var ic := IconView.make(IconView.Kind.LOGO_RIGHT, AppColors.TEAL_DARK, 150, 0.1)
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	p.add_child(ic)
	return UIKit.centered(p)


func _title() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 22)
	h.add_child(UIKit.label("ARROW", 84, AppColors.HEADING, "extrabold", 6))
	h.add_child(UIKit.label("ESCAPE", 84, AppColors.TEAL_MEDIUM, "bold", 6))
	return UIKit.centered(h)


func _divider() -> Control:
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	h.alignment = BoxContainer.ALIGNMENT_CENTER
	for i in 3:
		if i == 1:
			var d := IconView.make(IconView.Kind.DOT, AppColors.TEAL, 12)
			d.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			h.add_child(d)
		else:
			var line := ColorRect.new()
			line.color = AppColors.BORDER_DIM
			line.custom_minimum_size = Vector2(90, 3)
			line.size_flags_vertical = Control.SIZE_SHRINK_CENTER
			h.add_child(line)
	return h


func _tagline() -> Control:
	var p := UIKit.panel(UIKit.box(Color(AppColors.CARD, 0.8), 38, 36, 16))
	p.add_child(UIKit.label("ONE ARROW  •  ONE MOVE  •  ESCAPE", 22, AppColors.TEXT_SECONDARY, "semibold", 5))
	return UIKit.centered(p)


# Peeche halke arrows aur chhote mint dots
func _decor() -> void:
	var specs := [
		[IconView.Kind.ARROW_LEFT, Vector2(70, 380), 170.0, 0.10],
		[IconView.Kind.ARROW_UP, Vector2(850, 690), 150.0, 0.10],
		[IconView.Kind.ARROW_RIGHT, Vector2(800, 1500), 170.0, 0.10],
	]
	for s in specs:
		var px: float = s[2]
		var ic := IconView.make(s[0], AppColors.TEAL_MEDIUM, px, 0.07)
		ic.position = s[1]
		ic.size = Vector2(px, px)
		ic.modulate.a = s[3]
		add_child(ic)
	for pos in [Vector2(640, 520), Vector2(260, 1010), Vector2(570, 1010), Vector2(180, 1330)]:
		var d := IconView.make(IconView.Kind.DOT, AppColors.MINT, 14)
		d.position = pos
		d.size = Vector2(14, 14)
		add_child(d)


func on_back() -> void:
	pass   # splash ke dauran back ka kuch nahi
