class_name SaveManager
extends RefCounted

# Phone ki storage mein save hota hai (Windows par bhi user:// folder mein).
# Surakshit tareeka: pehle save.tmp me likhte hain, jaanchte hain, phir purani file ko
# save.bak bana ke nayi file ko save.json banate hain. Beech me phone band ho jaye ya
# file kharab ho jaye, to bhi purana save (save.bak) se wapas mil jata hai.
const PATH := "user://save.json"
const BAK := "user://save.bak"
const TMP := "user://save.tmp"

static var stars := {}      # level number -> stars (1 se 3)
static var loaded := false


# Kharab ya adhuri value se game ko crash na hone do
static func _int(v, default: int, lo: int, hi: int) -> int:
	if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
		return clampi(int(v), lo, hi)
	return default


static func _bool(v, default: bool) -> bool:
	if typeof(v) == TYPE_BOOL:
		return v
	return default


static func _read(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var d = JSON.parse_string(f.get_as_text())
	if typeof(d) == TYPE_DICTIONARY:
		return d
	return {}


static func load_data() -> void:
	if loaded:
		return
	loaded = true
	# save.json kharab ho to save.bak, phir save.tmp se koshish
	var d := _read(PATH)
	if d.is_empty():
		d = _read(BAK)
	if d.is_empty():
		d = _read(TMP)
	if d.is_empty():
		return   # naya khiladi: shuruaati values
	GameState.coins = _int(d.get("coins"), GameState.coins, 0, 100000000)
	GameState.hints = _int(d.get("hints"), GameState.hints, 0, 99999)
	GameState.undos = _int(d.get("undos"), GameState.undos, 0, 99999)
	GameState.removers = _int(d.get("removers"), GameState.removers, 0, 99999)
	GameState.sound_on = _bool(d.get("sound_on"), GameState.sound_on)
	GameState.music_on = _bool(d.get("music_on"), GameState.music_on)
	GameState.vibration_on = _bool(d.get("vibration_on"), GameState.vibration_on)
	GameState.tutorial_seen = _bool(d.get("tutorial_seen"), false)
	var ld = d.get("last_daily_claim")
	GameState.last_daily_claim = str(ld) if typeof(ld) == TYPE_STRING else ""
	GameState.current_level = _int(d.get("current_level"), 1, 1, GameState.TOTAL_LEVELS)
	stars.clear()
	var s = d.get("stars")
	if typeof(s) == TYPE_DICTIONARY:
		for k in s:
			var lv := int(str(k)) if str(k).is_valid_int() else 0
			if lv >= 1 and lv <= GameState.TOTAL_LEVELS:
				stars[lv] = _int(s[k], 0, 0, 3)


static func save_data() -> void:
	var s := {}
	for k in stars:
		s[str(k)] = stars[k]
	var d := {
		"coins": GameState.coins,
		"hints": GameState.hints,
		"undos": GameState.undos,
		"removers": GameState.removers,
		"sound_on": GameState.sound_on,
		"music_on": GameState.music_on,
		"vibration_on": GameState.vibration_on,
		"tutorial_seen": GameState.tutorial_seen,
		"last_daily_claim": GameState.last_daily_claim,
		"current_level": GameState.current_level,
		"stars": s,
	}
	var text := JSON.stringify(d)
	# 1) pehle tmp file me likho
	var f := FileAccess.open(TMP, FileAccess.WRITE)
	if f == null:
		return
	f.store_string(text)
	f.close()
	# 2) jaancho ki tmp sahi likhi gayi (adhuri file se purani save mat bigaado)
	if _read(TMP).is_empty():
		return
	# 3) purani save.json ko save.bak banao, tmp ko save.json
	var dir := DirAccess.open("user://")
	if dir == null:
		return
	if dir.file_exists("save.bak"):
		dir.remove("save.bak")
	if dir.file_exists("save.json"):
		dir.rename("save.json", "save.bak")
	dir.rename("save.tmp", "save.json")


# Level clear hone par bulao
static func record_clear(level: int, star_count: int) -> void:
	stars[level] = maxi(stars_of(level), star_count)
	save_data()


static func stars_of(level: int) -> int:
	return int(stars.get(level, 0))


static func is_completed(level: int) -> bool:
	return stars.has(level)


static func completed_count() -> int:
	return stars.size()


# Testing ke liye: saara progress mita do
static func reset_all() -> void:
	stars.clear()
	GameState.current_level = 1
	GameState.coins = GameState.START_COINS
	GameState.hints = GameState.START_HINTS
	GameState.undos = GameState.START_UNDOS
	GameState.removers = 0
	GameState.tutorial_seen = false
	GameState.last_daily_claim = ""
	save_data()
