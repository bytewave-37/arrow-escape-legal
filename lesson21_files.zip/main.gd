extends Control

var current: Control
var fade: ColorRect
var busy := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	SaveManager.load_data()
	SafeArea.update()
	RenderingServer.set_default_clear_color(AppColors.IVORY)
	fade = ColorRect.new()
	fade.color = AppColors.IVORY
	fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade.modulate.a = 0.0
	fade.z_index = 100
	add_child(fade)
	add_child(AudioManager.new())
	_show("splash")


func _make(target: String) -> Control:
	match target:
		"splash":
			return SplashScreen.new()
		"home":
			return HomeScreen.new()
		"play":
			return PlayScreen.new()
		"tutorial":
			return HowToPlayScreen.new()
		"levels":
			return LevelSelectScreen.new()
		"shop":
			return ShopScreen.new()
		"settings":
			return SettingsScreen.new()
	return PlaceholderScreen.make(target)


func _show(target: String) -> void:
	SafeArea.update()
	var screen := _make(target)
	screen.connect("navigate", Callable(self, "_on_navigate"))
	add_child(screen)
	move_child(screen, 0)   # fade hamesha upar rahe
	current = screen


func _on_navigate(target: String) -> void:
	if busy:
		return
	busy = true
	var tw := create_tween()
	tw.tween_property(fade, "modulate:a", 1.0, 0.16)
	await tw.finished
	if current != null:
		current.queue_free()
	_show(target)
	var tw2 := create_tween()
	tw2.tween_property(fade, "modulate:a", 0.0, 0.22)
	await tw2.finished
	busy = false


# Android ka Back button. Har screen apna on_back() de sakti hai; nahi to Home par jao.
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if busy or current == null:
			return
		if current.has_method("on_back"):
			current.call("on_back")
		else:
			_on_navigate("home")
